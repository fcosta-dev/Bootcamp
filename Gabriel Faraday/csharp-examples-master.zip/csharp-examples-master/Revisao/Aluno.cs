namespace Revisao
{
    public struct Aluno
    {
        public string Nome { get; set; }
        public decimal Nota { get; set; }
    }
}