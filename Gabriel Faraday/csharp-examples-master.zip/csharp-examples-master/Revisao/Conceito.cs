namespace Revisao
{
    public enum Conceito
    {
        A,
        B,
        C,
        D,
        E
    }
}